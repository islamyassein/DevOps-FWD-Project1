ReadMe file for Project 1 (Deploy Static Website on AWS) that mets the rubric specifications mentioned in "https://review.udacity.com/#!/rubrics/2573/view"

Folder "1-Website Files on S3 Screenshots", contains screenshot for a new created S3 bucket, uploaded website files, configured for static hosting, and allowed public access.

Folder "2-Website Distribution Screenshots", contains screenshots for CloudFront configured to retrieve and distriburte website files from S3 bucket

Folder "3-Web Browser Access", contains screen shots which dislays that website is properly accessible through CloudFront domain URL, Website-Endpoint URL, and moreover public accessible S3 object URL of file "index.html"


___________________________________________
The below are the needed URL for the created websites (CloudFront URL, Website-Enpoint URL)

CloudFront domain name URL
https://d3i7iqh4oyc901.cloudfront.net/

Website-endpoint URL
http://my-2734-4168-9893-islamyassein-bucket.s3-website-us-east-1.amazonaws.com/

S3 object URL for "index.html" 
https://my-2734-4168-9893-islamyassein-bucket.s3.amazonaws.com/index.html